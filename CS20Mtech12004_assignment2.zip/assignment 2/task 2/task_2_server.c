#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
	
#define PORT 6006
#define BUFFERSIZE 4096

void handle_connection(int i, fd_set *current_sockets, int server_socket, int fdmax);		

int main()
{
	//file descriptor set	
	fd_set current_sockets;
	fd_set ready_sockets;
	int fdmax, i;
	int server_socket= 0;
	int yes = 1;
	struct sockaddr_in my_addr, client_addr;
	
	//initializing current set using void FD_ZERO(fd_set *set)
	FD_ZERO(&current_sockets);
	FD_ZERO(&ready_sockets);
	
	//creating a socket using socket(family,type,protocol) and checking error
	if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		printf("Error in creating socket");
		exit(1);
	}
	//creating a socket structure and filling the values in its components	
	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(6006);
	my_addr.sin_addr.s_addr = INADDR_ANY;
	memset(my_addr.sin_zero, '\0', sizeof my_addr.sin_zero);
	//int setsockopt(int socket, int level, int option_name,const void *option_value, socklen_t option_len)	
	if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
		printf(" Error in setsockopt");
		exit(1);
	}
	//binding socket using bind(sockid, &addrport, size) and checking error
	if (bind(server_socket, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1) {
		printf("Error in binding");
		exit(1);
	}
	//listening to socket using listen(sockid, queueLimit) and checking error
	if (listen(server_socket, 10) == -1) {
		printf("Error in listening");
		exit(1);
	}
	printf("Server is ready\n");
	fflush(stdout);
	//void FD_SET(int fd, fd_set *set)
	FD_SET(server_socket, &current_sockets);
	//fdmax is maximum size of fd_set
	fdmax = server_socket;
	while(1){
		//creating a temporary copy as FD_SET is destructive
		ready_sockets = current_sockets;
		
		//int select(int nfds, fd_set *readfds, fd_set *writefds,fd_set *exceptfds, struct timeval *timeout);
		if(select(fdmax+1, &ready_sockets, NULL, NULL, NULL) == -1){
			printf(" Error in select");
			exit(4);
		}
		
		for (i = 0; i <= fdmax; i++){
			if (FD_ISSET(i, &ready_sockets)){
				if (i == server_socket)
					{
						//this is a new connection
						socklen_t addrlen;
						int client_socket;
						
						addrlen = sizeof(struct sockaddr_in);
						//accepting connection using accept(sockid, &clientAddr, &addrLen) and checking error
						if((client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addrlen)) == -1) {
							printf("Error in accept");
							exit(1);
						}else {
							//adding client socket to the list of current sockets
							FD_SET(client_socket, &current_sockets);
							if(client_socket > fdmax){
								fdmax = client_socket;
							}
							printf("new client connection on port %d \n", ntohs(client_addr.sin_port));
						}
					}
				else
					// already a connection and now we will handle this connection 
					handle_connection(i, &current_sockets, server_socket, fdmax);
			}
		}
	}
	return 0;
}

void handle_connection(int i, fd_set *current_sockets, int server_socket, int fdmax)
{
	int bytes_received, j;
	char recv_buf[BUFFERSIZE], buf[BUFFERSIZE];
	//receiving meassage from clients
	if ((bytes_received = recv(i, recv_buf, BUFFERSIZE, 0)) <= 0) {
		if (bytes_received == 0) {
			printf("socket %d disconnected\n", i);
		}else {
			printf(" Error in receiving");
		}
		close(i);
		//clearing the socket from list of FD which are being watched currently 
		//void FD_CLR(int fd, fd_set *set)
		FD_CLR(i, current_sockets);
	}else { 
	// sending message to all clients which are available in current_sockets
		for(j = 0; j <= fdmax; j++)
			{
			if (FD_ISSET(j, current_sockets)){
				if (j != server_socket && j != i) {
					//sending to all client sockets except himself with error checking
					if (send(j, recv_buf, bytes_received, 0) == -1) {
						printf("Error in sending ");
					}
				}
			}
		}
	}	
}
