#include <stdlib.h> 
#include <stdio.h>
#include <string.h> 
#include <sys/socket.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <sys/types.h> 
#include <unistd.h>
#include <arpa/inet.h>
#include <math.h>
#include <time.h>
#include<sys/time.h>


#define MAX 1024 
#define SA struct sockaddr

void FileTransfer(int sockfd, struct sockaddr_in clientAddress){ 	
	
	char messageBuffer[MAX]; 
	char fileName[MAX]; 
	int length; // Length of UDP message
	int n; // Used for index identification
	clock_t begin, end; // Used to measure transfer time.
	double runTime; // Used to determine transfer time.

		bzero(messageBuffer, MAX); 		
		length = sizeof(clientAddress);

		// Initial request from client
		/*packetType::InitialRequest
			{
			packetType,
			sequenceNum,
			ackNum,
			packetChecksum,
			}*/
		
		n = recvfrom(sockfd, messageBuffer, sizeof(messageBuffer), 0, (struct sockaddr*) &clientAddress, &length);
		messageBuffer[n] = '\0';
		// print buffer which contains the client contents 
		printf("Client is requesting %s \n" , messageBuffer);
		// Attempt to open specified file
		memcpy(fileName, messageBuffer, sizeof(messageBuffer)); // Keep local copy of (potential) filename
		FILE* serverFile = fopen(fileName, "r"); // Open file in read mode, store as serverFile

		// If the file exists on the server
		if(serverFile != NULL){
			// Inform client file exists
			/* packetType::InitialResponse
				{
				packetType,
				sequenceNum,
				file size,
				window size,
				packetChecksum,
				}*/
			sendto(sockfd, "OK", sizeof("OK"), 0, (const struct sockaddr*) &clientAddress, sizeof(clientAddress));

			// Reset messageBuffer, wait for client to acknowledge the OK message
			bzero(messageBuffer, sizeof(messageBuffer));
			n = recvfrom(sockfd, messageBuffer, sizeof(messageBuffer), 0, (struct sockaddr*) &clientAddress, &length);
			messageBuffer[n] = '\0';

			// If read message is OK send file
			if ((strncmp(messageBuffer, "OK", 2)) == 0) {
			
			/*
			packetType::DataPack
				{
				packetType
				sequenceNum,
				ackNum,
				packetChecksum,
				payloadLength,
				}
			*/

				// Init Variables Server Side
				int transferFlag = 1; // Flag used to break out of while loop
				int packetSize; // Size of each packet being sent
				int lastAck = -1; // Int of last received acknowledge. Set to -1 for no acks.
				int lastSegment; // Int of last sent segnment number.
				int j = 0; 
				clock_t timeoutStart, timeoutEnd; // Used for timeout timing (Go-Back-N)
				double timeOut; // Used to determine transfer time.
				unsigned int checksum = 0;
			

				begin = clock(); // Start File Transfer Clock
				
				// Reset messageBuffer
				bzero(messageBuffer, sizeof(messageBuffer)); 
				printf("Sending file %s to Client... \n", fileName);

					// Continuously pipeline file contents following Go-Back-N protocol until EOF
					while(transferFlag == 1){	
						
						
						//set socket timeout option so it will timeout on recv()
						  struct timeval tv;
						  tv.tv_sec = 2; //2 seconds
						  tv.tv_usec = 0;
						  setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof tv);


						// Send Current Segment's Number
						bzero(messageBuffer, sizeof(messageBuffer));
						sprintf(messageBuffer, "%d", j); 
						sendto(sockfd, messageBuffer, sizeof(messageBuffer), 0, (const struct sockaddr*) &clientAddress, sizeof(clientAddress));

						// Update Last Segement Number
						lastSegment = atoi(messageBuffer); 
						printf("SERVER: Sending segment %s \n", messageBuffer);

						// Set file read head to the bit location of the last ACK'd packet. (Maintain window)
						// fseek ( FILE * stream, long int offset, int origin );
						//For streams open in text mode, offset shall either be zero or a value returned by a previous call to ftell, and origin shall necessarily be SEEK_SET.
						fseek(serverFile, (sizeof(char) * (MAX) * (j)), SEEK_SET); // Offset max by 8 bits for size of checksum and '\0'

						// Reset Message Buffer and read in packet from server file
						bzero(messageBuffer, MAX);
						//size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream)
						//The C library function size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream) reads data from the given stream into the array pointed as ptr.
						packetSize = fread(messageBuffer, sizeof(char), sizeof(messageBuffer), serverFile); 
						packetSize += 8; // Update packetsize (adding checksum bits)

						// Send File
						if(sendto(sockfd, messageBuffer, packetSize, 0, (struct sockaddr*) &clientAddress, length) < 0){
							printf("SERVER: ERROR Failed to send file %s. Closing connection. \n", fileName);
							exit(0);
						}

						// Receive latest acknowledge from Client.
						bzero(messageBuffer, sizeof(messageBuffer));
						n = recvfrom(sockfd, messageBuffer, sizeof(messageBuffer), 0, (struct sockaddr*) &clientAddress, &length);
						if(n==-1){
						printf("Time out waiting for ACK \n");
						//continue;
						}
						
						messageBuffer[n] = '\0';

						// Update Last ACK value if client does not report bit errors. If not, ignore ACK.
						if (lastAck == atoi(messageBuffer) - 1){
							lastAck = atoi(messageBuffer);
						}

						printf("SERVER: Receiving acknowledge %d \n", lastAck);

						// Break out of while loop if the final packet has been received and acknowledged. (Stop sending packets)
						if (packetSize == 0 || packetSize < MAX){
							if(lastAck == lastSegment){
								transferFlag = 0;
								break;
							}
						}
					

					
					j = lastAck + 1;
				}

				// End timer and store value in runTime.
				end = clock(); 
				runTime = (double)(end - begin) / CLOCKS_PER_SEC;

				// Display success message
				printf("SERVER: File successfully sent to client in %f seconds! \n", runTime);
			}
		}
		else{
			
			printf("SERVER: ERROR file %s not found on server. \n", fileName);
			sendto(sockfd, "NULL", sizeof("NULL"), 0, (struct sockaddr*) &clientAddress, length);
		}

	close(sockfd);
}

int main(){	
	
	int portVal = 6002; 
	int serverSocket; 
	struct sockaddr_in serverAddress; 
	struct sockaddr_in clientAddress; 
	
	srand(time(NULL));	
	
	// Creating UDP Socket
	serverSocket = socket(AF_INET, SOCK_DGRAM, 0); 
	if (serverSocket == -1) { 
		printf("Socket creation failed. \n"); 
		exit(0); 
	} 
	else{
		printf("Socket creation successful. \n");
	}
	
	
	
	bzero(&serverAddress, sizeof(serverAddress)); 
	
	// Assign the IP and Port Number for the Server address.
	serverAddress.sin_family = AF_INET; 
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddress.sin_port = htons(portVal); 
	
	// Bind server socket with server address.
	if ((bind(serverSocket, (SA*)&serverAddress, sizeof(serverAddress))) != 0) { 
		printf("Socket binding failed. \n"); 
		exit(0); 
	} 
	else{
		printf("Socket binding successful. \n"); 
	}
	
	// function for file transfer
	FileTransfer(serverSocket, clientAddress); 
	
	// Close Server Socket 
	close(serverSocket);
	return 0; 
}
