To run task 1
we have to enter the url 

I have not completed the code, so there will be only sending and receiving response part but no message will be printed after submitting the url.

I haven't traversed the received packet and printed the received IP.

