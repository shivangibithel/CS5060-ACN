#include <stdlib.h> 
#include <stdio.h>
#include <string.h> 
#include <sys/socket.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <sys/types.h>
#include <unistd.h> 
#include <arpa/inet.h>
#include <time.h>


#define MAX 1024 
#define SA struct sockaddr


void FileTransfer(int sockfd, struct sockaddr_in serverAddress){ 
	// Init Variables
	char currWindow[MAX]; // Window buffer to store data received
	char messageBuffer[MAX]; // Buffer to store segment number
	char fileName[MAX]; // buffer to store file name
	int length; // Length of UDP message
	int n;
	clock_t begin, end; //used to calculate total time of the file transfer
	double runTime; 

		bzero(messageBuffer, sizeof(messageBuffer));		
		// Get user input for file name, send input to server
		printf("Enter the filename you wish to download "); 
		scanf("%s", messageBuffer);	
		memcpy(fileName, messageBuffer, sizeof(messageBuffer)); 
		
		// Send filename to server
		sendto(sockfd, messageBuffer, MAX, 0, (const struct sockaddr *)&serverAddress, sizeof(serverAddress));
		
		// Reset messageBuffer, wait for OK message to confirm file existance.
		bzero(messageBuffer, sizeof(messageBuffer));
		n = recvfrom(sockfd, messageBuffer, MAX, 0, (struct sockaddr *)&serverAddress, &length);
		messageBuffer[n] = '\0';

		// If server finds file start recieveing it.
		if ((strncmp(messageBuffer, "OK", 2)) == 0) {

			// Print OK message
			printf("SERVER: %s\n", messageBuffer);

			// Send ok message back to server to begin data transmission
			bzero(messageBuffer, sizeof(messageBuffer));
			sendto(sockfd, "OK", sizeof("OK"), 0, (const struct sockaddr *)&serverAddress, sizeof(serverAddress));
			
			// Receive File from Server
			printf("Receiveing %s from Server and saving it. \n", fileName);
			
			// Create file in write mode
			FILE *clientFile = fopen(fileName, "w"); 
			
			// If the file is null something went wrong, else download file from server
			if(clientFile == NULL){
				printf("ERROR File %s cannot be opened. \n", fileName);
			}
			else{
				
				bzero(messageBuffer, MAX);
				int Flag = 1; 
				int packetSize = 0; // Size of each packet received from server
				int lastAck = -1; // Int of last received acknowledge. Set to -1 for no acks.
				int lastSegment; // Int of last sent segnment number.
				int checksum = 0; 
				int windowSize=5;
			

				begin = clock(); 

				// Transfer File From Server To Client (Go-Back-N)
				while(Flag == 1){
				
				    int count=1;
				    
				    while (count<=windowSize)
				    {
					// Reset File Buffer
					bzero(currWindow, sizeof(currWindow));
					// Receive the Segment Number from server
					bzero(messageBuffer, sizeof(messageBuffer));
					n = recvfrom(sockfd, messageBuffer, MAX, 0, (struct sockaddr *)&serverAddress, &length);
					messageBuffer[n] = '\0';
					printf("Receiveing segment %s \n", messageBuffer);

					// Set last received segment number
					lastSegment = atoi(messageBuffer);

					// Receive Packet, store in currWindow.
					packetSize = recvfrom(sockfd, currWindow, sizeof(currWindow), 0, (struct sockaddr *)&serverAddress, &length);
					
					count++;
					fwrite(currWindow, sizeof(char), packetSize, clientFile);
						
					}
					lastAck = lastSegment; 					
					//if outof order packets will be received...
					// Send acknowledgement for last successfully received segment.
					bzero(messageBuffer, sizeof(messageBuffer));
					sprintf(messageBuffer, "%d", lastAck); 
					sendto(sockfd, messageBuffer, sizeof(messageBuffer), 0, (const struct sockaddr *)&serverAddress, sizeof(serverAddress));
					printf("Sending acknowledge %s \n", messageBuffer);

					
					// Break out of while loop if last packet has been received and ack'd.
						if (packetSize == 0 || packetSize < MAX){
							if(lastAck == lastSegment){
								Flag = 0;
								break;
							}
						}

				}	
				
			}
			// End timer and store value in runTime.
			end = clock(); 
			runTime = (double)(end - begin) / CLOCKS_PER_SEC;

			// Display success message and close File
			printf("File received from server in %f seconds. \n", runTime);
			fclose(clientFile); // Close File
		}
		else {
			// Else if no OK is received file is not on server.
			printf("File %s not found on server. \n", fileName);
		}

	close(sockfd);
}


int main(){
	
	char* ipAddress="127.0.0.1"; // Destination IP Address	
	int portVal =8080; // Destination port
	int clientSocket; // Socket for the client
	struct sockaddr_in serverAddress; // Socket address for server
	
	// Creating client socket
	clientSocket = socket(AF_INET, SOCK_DGRAM, 0); 
	if (clientSocket == -1) { 
		printf("Socket creation failed. \n"); 
		exit(0); 
	} 
	else{
		printf("Socket creation successful. \n"); 
	}
	
	bzero(&serverAddress, sizeof(serverAddress)); 	
	// Assign the IP and Port Number for the destination address.
	serverAddress.sin_family = AF_INET; 
	serverAddress.sin_addr.s_addr = inet_addr(ipAddress); 
	serverAddress.sin_port = htons(portVal); 

	// File transfer over UDP.
	FileTransfer(clientSocket, serverAddress); 
	
	close(clientSocket); 
	return 0; 
} 
