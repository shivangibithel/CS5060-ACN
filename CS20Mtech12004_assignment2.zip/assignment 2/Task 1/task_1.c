#include<stdio.h>	
#include<string.h>	
#include<stdlib.h>	
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h>

struct dnsHeader
{
	unsigned short id; 

	unsigned char recursion :1;
	unsigned char truncate :1;
	unsigned char authoritative_answer :1;
	unsigned char opcode :4; 
	unsigned char query :1; 

	unsigned char responseCode :4; 
	unsigned char checking :1; 
	unsigned char authenticated_data :1; 
	unsigned char reserved :1; 
	unsigned char recurssion :1; 

	unsigned short nquery; 
	unsigned short nanswer; 
	unsigned short nauthority; 
	unsigned short nresource; 
};

struct question{
unsigned short quesType;
unsigned short quesClass;
};

int main()
{
	unsigned char host_name[50];
	printf("Enter name of host to search  ");
	scanf("%s" , host_name);
	
	int query_type =1;
	unsigned char buffer[4096],*query_name,*reader;
	int i , j , stop;

	struct sockaddr_in my_addr;
	struct sockaddr_in destination;
	

	struct dnsHeader *dns = NULL;
	struct question *queryinfo = NULL;
	// creating a socket
	int server_socket = socket(AF_INET , SOCK_DGRAM , IPPROTO_UDP); 
	
	if(server_socket==-1){
	printf("Error in creating socket");
		exit(1);
	}
	//creating a socket structure and filling the values in its components
	destination.sin_family = AF_INET;
	destination.sin_port = htons(53);
	destination.sin_addr.s_addr = inet_addr("192.168.35.52"); 
	//Setting the DNS structure
	dns = (struct dnsHeader *)&buffer;

	dns->id = (unsigned short) htons(getpid());
	dns->query = 0; 
	dns->opcode = 0; 
	dns->authoritative_answer = 0; 
	dns->truncate = 0; 
	dns->recursion = 1; 
	dns->recurssion = 0; 
	dns->reserved = 0;
	dns->authenticated_data = 0;
	dns->checking = 0;
	dns->responseCode = 0;
	dns->nquery = htons(1); 
	dns->nanswer = 0;
	dns->nauthority = 0;
	dns->nresource = 0;

	query_name =(unsigned char*)&buffer[sizeof(struct dnsHeader)];
	// converting to dns format
	int a = 0 , i;
	strcat((char*)host_name,".");
	
	for(i = 0 ; i < strlen((char*)host_name) ; i++) 
	{
		if(host_name[i]=='.') 
		{
			*dns =*dns + i-a;
			for(;a<i;a++) 
			{
				*dns= *dns + host_name[a];
			}
			a=i+1;
		}

	}
	*dns++='\0';
	
	queryinfo =(struct question*)&buffer[sizeof(struct dnsHeader) + (strlen((const char*)query_name) + 1)]; 

	queryinfo->quesType = htons( query_type ); 
	queryinfo->quesClass = htons(1); 
	//sending the standard query to dns server
	if( sendto(server_socket,(char*)buffer,sizeof(struct dnsHeader) + (strlen((const char*)query_name)+1) + sizeof(struct question),0,(struct sockaddr*)&destination,sizeof(destination)) < 0)
	{
		printf("error in sendto");
	}
	// receiveing dns response 
	if(recvfrom (server_socket,(char*)buffer , 4096 , 0 , (struct sockaddr*)&destination , (socklen_t*)&i ) < 0)
	{
		printf("error in recvfrom");
	}
return 0;
}
