

To run task 2 
I have implicitly added the server port in client program
no need to enter anything at server or client side to connect

After connection clients can send message to each other
whenever a client writes bye and press enter, that client will get disconnected from the chat

server will run infinitely.
screenshots are attached in doc file for reference.
 