#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
	
#define BUFFERSIZE 4096
		
void handle_connection(int i, int client_socket);
			
int main()
{
	int client_socket, fdmax, i;
	struct sockaddr_in client_addr;
	//file descriptor set
	fd_set current_sockets;
	fd_set ready_sockets;
	
	//creating a socket using socket(family,type,protocol) and checking error
	if ((client_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		printf(" error in creating socket");
		exit(1);
	}
	//creating a socket structure and filling the values in its components
	client_addr.sin_family = AF_INET;
	client_addr.sin_port = htons(6006);
	client_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	memset(client_addr.sin_zero, '\0', sizeof client_addr.sin_zero);
	
	//int connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
	if(connect(client_socket, (struct sockaddr *)&client_addr, sizeof(struct sockaddr)) == -1) {
		printf("Error in connect");
		exit(1);
	}
	
	//initializing current set using void FD_ZERO(fd_set *set)
	FD_ZERO(&current_sockets);
    FD_ZERO(&ready_sockets);
	//void FD_SET(int fd, fd_set *set)
    FD_SET(0, &current_sockets);
    FD_SET(client_socket, &current_sockets);
	//fdmax is maximum size of fd_set
	fdmax = client_socket;
	
	while(1){
		//creating a temporary copy as FD_SET is destructive
		ready_sockets = current_sockets;
		
		//int select(int nfds, fd_set *readfds, fd_set *writefds,fd_set *exceptfds, struct timeval *timeout);
		if(select(fdmax+1, &ready_sockets, NULL, NULL, NULL) == -1){
			printf("Error in select");
			exit(4);
		}
		
		for(i=0; i <= fdmax; i++ )
			if(FD_ISSET(i, &ready_sockets))
				//handling this connection, sending and receiving messages
				handle_connection(i, client_socket);
	}
	printf("client disconnected\n");
	//closing the socket
	close(client_socket);
	return 0;
}

void handle_connection(int i, int client_socket)
{
	//creating two buffers with maximum buffer size
	char send_buf[BUFFERSIZE];
	char recv_buf[BUFFERSIZE];
	int bytes_received;
	
	if (i == 0){
		//char *fgets(char *str, int n, FILE *stream)
		//reads a line from the specified stream and stores it into the string pointed to by str
		fgets(send_buf, BUFFERSIZE, stdin);
		//if client sends a "bye" then the connection for this client will be disconnected and bye message will not be sent.
		if (strcmp(send_buf , "bye\n") == 0) {
			exit(0);
		}else
			//sending message to server
			send(client_socket, send_buf, strlen(send_buf), 0);
	}else {
		//receiving message from server
		bytes_received = recv(client_socket, recv_buf, BUFFERSIZE, 0);
		recv_buf[bytes_received] = '\0';
		printf("%s\n" , recv_buf);
		//flushing standard output stream
		fflush(stdout);
	}
}
