//NAT SERVER
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <linux/ip.h>
#include <linux/udp.h>


using namespace std;
const int backLog = 3;
const int maxDataSize = 1460;
#define PCKT_LEN 8192

unsigned short csum(unsigned short *buf, int nwords)
{
  unsigned long sum;
  for(sum=0; nwords>0; nwords--)
    sum += *buf++;
  sum = (sum >> 16) + (sum &0xffff);
  sum += (sum >> 16);
  return (unsigned short)(~sum);
}
//sending data as TCP message
string generatestr(int count, u_int16_t dst_port){
string serverIpAddr = "127.0.0.1";
string dest=":";
string abc="Received "+ to_string(count);
abc= abc+" from ";
abc= abc + serverIpAddr;
abc= abc + dest;
abc= abc + to_string(dst_port);
return abc;
}

void recvdata(u_int32_t src_addr,u_int16_t src_port)
{
char recvbuffer[PCKT_LEN];

  struct sockaddr_in ServerAddr,ClientAddr;
  int rsd = socket(AF_INET, SOCK_DGRAM,0);
  if(rsd<0)
  printf("Socket error\n");
  memset(&ClientAddr, 0, sizeof(ClientAddr));
  socklen_t ServerAddrLen = sizeof(ServerAddr);
  ClientAddr.sin_family = AF_INET;
  ClientAddr.sin_addr.s_addr = src_addr;
  ClientAddr.sin_port = htons(src_port);

int ret=bind(rsd, (struct sockaddr *) &ClientAddr, sizeof(ClientAddr));
 if(ret<0)
 printf("Bind error\n");


  memset(&recvbuffer,0,PCKT_LEN);
  printf("Waiting to receive\n");

  int dataRecvd=recvfrom(rsd,&recvbuffer,sizeof(recvbuffer),0,(struct sockaddr *) &ServerAddr, &ServerAddrLen);
  printf("Received\n");
}

int main()
{

uint16_t serverPort=3002;
string serverIpAddr = "127.0.0.1";
cout<<"Enter the ip address and port number for NAT server"<<endl;
cin>>serverIpAddr;  //server IP of nat
cin>>serverPort; //server port for NAT server to run

u_int16_t src_port, dst_port;
u_int32_t src_addr, dst_addr;
const char* src_addr1="127.0.0.1";
const char* dst_addr1="192.168.0.105";
//src_addr=serverIpAddr.c_str();
src_addr = inet_addr(src_addr1);
dst_addr = inet_addr(dst_addr1);
src_port=3006;//random sorce port to be stored in mapping table
dst_port=5002;
cout<<"Enter destination port for udp server"<<endl;
cin>>dst_port; 


int serverSocketFd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
if(!serverSocketFd)
{
   cout<<"Error creating socket"<<endl;
   exit(1);
}

struct sockaddr_in serverSockAddressInfo;
serverSockAddressInfo.sin_family = AF_INET;
serverSockAddressInfo.sin_port = htons(serverPort);
serverSockAddressInfo.sin_addr.s_addr = INADDR_ANY;
inet_pton(AF_INET, serverIpAddr.c_str(), &(serverSockAddressInfo.sin_addr));
memset(&(serverSockAddressInfo.sin_zero), '\0', 8);
printf("Server listening on IP %x:PORT %d \n",serverSockAddressInfo.sin_addr.s_addr, serverPort);

int ret = bind(serverSocketFd, (struct sockaddr *)&serverSockAddressInfo, sizeof(struct sockaddr)); 
if(ret<0)
{
   cout<<"Error binding socket"<<endl;
   close(serverSocketFd);
   exit(1);
}
ret = listen(serverSocketFd, backLog);
if(!serverSocketFd)
{
   cout<<"Error listening socket"<<endl;
   close(serverSocketFd);
   exit(1);
}

socklen_t sinSize = sizeof(struct sockaddr_in);
int flags = 0;
int dataRecvd = 0, dataSent = 0;
struct sockaddr_in clientAddressInfo;
char rcvDataBuf[maxDataSize], sendDataBuf[maxDataSize];
char rcvDataBuf2[maxDataSize], sendDataBuf2[maxDataSize];
string sendDataStr;

memset(&clientAddressInfo, 0, sizeof(struct sockaddr_in));
memset(&rcvDataBuf, 0, maxDataSize);
int newClientFd = accept(serverSocketFd, (struct sockaddr *)&clientAddressInfo, &sinSize);
if (!newClientFd)
   {
       cout<<"Error with new client connection "<<endl;
       close(serverSocketFd);
       exit(1);
   }

cout<<"New client arrived"<<endl;
cin.ignore();

//udp sending socket 
int sd;
char buffer[PCKT_LEN];
struct iphdr *ip = (struct iphdr *) buffer;
struct udphdr *udp = (struct udphdr *) (buffer + sizeof(struct iphdr));
  struct sockaddr_in sin;
  int one = 1;
  const int *val = &one;

  memset(buffer, 0, PCKT_LEN);
    // create a raw socket with UDP protocol
  sd = socket(PF_INET, SOCK_RAW, IPPROTO_UDP);
  if (sd < 0) {
    perror("socket() error");
    exit(2);
  }
  printf("RAW socket is created.\n");

  // inform the kernel do not fill up the packet structure, we will build our own
  if(setsockopt(sd, IPPROTO_IP, IP_HDRINCL, val, sizeof(one)) < 0) {
    perror("setsockopt() error");
    exit(2);
  }
  printf("Socket option IP_HDRINCL is set.\n");

  sin.sin_family = AF_INET;
  sin.sin_port = htons(dst_port);
  sin.sin_addr.s_addr = dst_addr;

  // IP header
  ip->ihl      = 5;
  ip->version  = 4;
  ip->tos      = 16; 
  ip->id       = htons(54321);
  ip->ttl      = 64; // hops
  ip->protocol = 17; // UDP
  // source IP address
  ip->saddr = src_addr;
  ip->daddr = dst_addr;
  

  // UDP header
  udp->source = htons(src_port);
  // destination port number
  udp->dest = htons(dst_port);
  
int count=0;  
while(1)
{

//receiving data from TCP client
   memset(&rcvDataBuf, 0, maxDataSize);
   //ssize_t recv(int socket, void *buffer, size_t length, int flags);
   dataRecvd = recv(newClientFd, &rcvDataBuf, maxDataSize, flags);
   count++; 
   string rcvDataBuf2= generatestr(count,dst_port); 
   
     
//converting data to udp packet and sending to udp server

  char *data;
  data = buffer + sizeof(struct iphdr) + sizeof(struct udphdr);
  strcpy(data,rcvDataBuf);
  cout<<"Data received from client:  ";
  printf("%s\n",buffer + sizeof(struct iphdr) + sizeof(struct udphdr));

  // calculating the checksum
  ip->tot_len  = sizeof(struct iphdr) + sizeof(struct udphdr)+strlen(data);
  udp->len = htons(sizeof(struct udphdr)+strlen(data));
  ip->check = csum((unsigned short *)buffer,
                   sizeof(struct iphdr) + sizeof(struct udphdr)+strlen(data));
  
  //ssize_t sendto(int socket, const void *message, size_t length,int flags, const struct sockaddr *dest_addr,socklen_t dest_len);
  if (sendto(sd, buffer, ip->tot_len, 0, (struct sockaddr *)&sin, sizeof(sin)) < 0)
  {
    perror("sendto()");
    exit(3);
  }
  else{
  printf("one packet is sent.\n");   
  } 

 
//receiving data from udp server into raw socket 

socklen_t clientAddrLen = sizeof(sin);
memset(&rcvDataBuf, 0, maxDataSize);
//ssize_t recvfrom(int socket, void *restrict buffer, size_t length,int flags, struct sockaddr *restrict address,socklen_t *restrict address_len);
int DataRecvd=recvfrom(sd, &rcvDataBuf, maxDataSize, flags,(struct sockaddr *) &sin, &clientAddrLen);
//cout<<"Received bytes ="<<DataRecvd<<endl;


//sending data received from UDP server to the TCP client
//ssize_t send(int socket, const void *buffer, size_t length, int flags);
dataSent = send(newClientFd, rcvDataBuf2.c_str(), sizeof(rcvDataBuf2), flags);

}

cout<<"All done closing server socket now"<<endl;
close(serverSocketFd);

return 0;
}
