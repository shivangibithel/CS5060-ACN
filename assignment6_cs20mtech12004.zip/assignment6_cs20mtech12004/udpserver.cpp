#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <arpa/inet.h>

using namespace std;
const int maxDataSize = 4096;
int main()
{
int udpServPort=5002;
string udpServerIP="192.168.0.105";
cout<<"Enter port number to listen the connections for"<<endl;
//cin>>ServerIP;
cin>>udpServPort;
int servSock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

struct sockaddr_in echoServAddr;
echoServAddr.sin_family = AF_INET;
echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY);
echoServAddr.sin_port = htons(udpServPort);

int ret=bind(servSock, (struct sockaddr *) &echoServAddr, sizeof(echoServAddr));
if(ret<0){
printf("error in binding");
}

int flags = 0;
int dataRecvd = 0, dataSent = 0;
struct sockaddr_in echoClientAddr;
char rcvDataBuf[maxDataSize], sendDataBuf[maxDataSize];
int count=0;
for (;;) 
{
socklen_t clientAddrLen = sizeof(echoClientAddr);
memset(&rcvDataBuf, 0, maxDataSize);
dataRecvd=recvfrom(servSock, &rcvDataBuf, maxDataSize, flags,(struct sockaddr *) &echoClientAddr, &clientAddrLen);
if(dataRecvd<0){
printf("error");
}
//if(count==1){
//printf("%s , %d\n",rcvDataBuf,dataRecvd);}
printf("%s , %d\n",rcvDataBuf,dataRecvd);
count++;

string send="Received "+ to_string(count);
send=send+ " from";
send=send + inet_ntoa(echoClientAddr.sin_addr);
send=send+":";
send=send+to_string(udpServPort);
//send to raw socket
if(sendto(servSock, send.c_str(), sizeof(send), 0, (const struct sockaddr*) &echoClientAddr, sizeof(echoClientAddr))<0)
//if(sendto(servSock, "OK", sizeof("OK"), 0, (const struct sockaddr*) &echoClientAddr, sizeof(echoClientAddr))<0)
{
cout<<"error in sendto"<<endl;
}
else{
cout<<"sent to "<<inet_ntoa(echoClientAddr.sin_addr)<<" : "<<ntohs(echoClientAddr.sin_port)<<endl;
}
}
close(servSock);
}
